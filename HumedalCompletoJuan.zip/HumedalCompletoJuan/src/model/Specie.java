package model;

public class Specie {
	
	private String type;
	private String name;
	private String scienceName;
	private String migratory;
	private String specieType;



	public Specie(String type, String name, String scienceName, String migratory, String specieType){
		this.type=type;
		this.name=name;
		this.scienceName=scienceName;
		this.migratory=migratory;
		this.specieType=specieType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName(){
		return name;
	}

	public void setName(String name){
		this.name=name;
	}
	public String getScienceName(){
		return scienceName;
	}
	public void setScienceName(String scienceName){
		this.scienceName=scienceName;
	}
	public String getMigratory(){
		return migratory;
	}
	public void setMigratory(String migratory){
		this.migratory=migratory;
	}
	public String getSpecieType(){
		return specieType;
	}
	public void setSpecieType(String specieType){
		this.specieType=specieType;
	}
@Override
	public String toString() {
		return "type of event: " +type+ "date of the event: " +name+ "who performs the event: " +scienceName+ "price of the event: " +migratory+ "description of the event: " +specieType;
	}
}


