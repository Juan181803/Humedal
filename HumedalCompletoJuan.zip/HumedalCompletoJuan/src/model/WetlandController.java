package model;

public class WetlandController {

	private Wetland[] wetlands;

	public WetlandController() {

		 wetlands = new Wetland[80];

	}

	public boolean saveWetland(String name, String zone, String type, double km2, String url, String typeOfArea, String village, String neighborhood){
		boolean stopFlag = false;

		Wetland myWetland = new Wetland(name, zone, type, km2, url, typeOfArea, village, neighborhood);

		for (int i = 0; i < wetlands.length && !stopFlag; i++) {
			//System.out.println("hola");
			if (wetlands[i] == null) {
				//System.out.println("hola");
				myWetland.setId((i + 1) + "");
				wetlands[i] = myWetland;
				stopFlag = true;

			}

		}

		return stopFlag;

	}
	public String showWetlandsList() {

		String msg = "";

		for (int i = 0; i < wetlands.length; i++) {

			if (wetlands[i] != null) {

				
				msg += "\n" + wetlands[i].getId() + ". " + wetlands[i].getName();
				//System.out.println(wetlands[i].getName());
			}
		}

		return msg;

	}
	public boolean saveEvent(String wetlandID, String event, int day, int month, int year, String who, double value, String description) {

		boolean stopFlag = false;

		for (int i = 0; i < wetlands.length && !stopFlag; i++) {

			if (wetlands[i] != null) {

				if ((i + 1 + "").equals(wetlandID)) {

					stopFlag = wetlands[i].addEvent(event, day, month, year, who, value, description);

				}

			}

		}

		return stopFlag;

	}
	public boolean saveSpecie(String specieID, String type, String name, String scienceName, String migratory, String specieType) {

		boolean stopFlag = false;

		for (int i = 0; i < wetlands.length && !stopFlag; i++) {

			if (wetlands[i] != null) {

				if ((i + 1 + "").equals(specieID)) {

					stopFlag = wetlands[i].addSpecie(type, name, scienceName, migratory, specieType);

				}

			}

		}

		return stopFlag;

	}
	public String maintenancePerYear(int userYear) {
		int j = 0;
		String msg = "\nFor the year " +userYear;

		for (int i = 0; i < wetlands.length; i++) {

			if (wetlands[i] != null && wetlands[i].getEventArray()!=null) {

				for (int k=0; k<wetlands[i].getEventArray().length; k++){

					if (wetlands[i].getEventArray()[k]!= null){

				if (wetlands[i].getEventArray()[k].getDate().getYear()==userYear && wetlands[i].getEventArray()[k].getEvent().equals("Maintenance")){
					j++;
				}
				}
				}
				msg +="\nin the wetland with name: " +wetlands[i].getName()+ " were "+j+" maintenances";
				//System.out.println(wetlands[i].getName());
			}
		}

		return msg;

	}
	/*public boolean createEvent(String event, int day, int month, int year){

	}*/

	}