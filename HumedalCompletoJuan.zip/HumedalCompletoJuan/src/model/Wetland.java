package model;

public class Wetland {

	private int maintenanceCount;
	private String id;
	private String name;
	private String zone;
	private String type;
	private double km2;
	private String url;
	private String typeOfArea;
	private String village;
	private String neighborhood;
	private Event[] eventArray;
	private Specie[] specieArray;


	public Wetland(String name, String zone, String type, double km2, String url, String typeOfArea, String village, String neighborhood){
		this.maintenanceCount=0;
		this.id="";
		this.name=name;
		this.zone=zone;
		this.type=type;
		this.km2=km2;
		this.url=url;
		this.typeOfArea=typeOfArea;
		this.village=village;
		this.neighborhood=neighborhood;
		eventArray = new Event[100];
		specieArray = new Specie[100];
	}
	public Wetland(){

	}

		public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		public String getName(){
			return name;
		}

		public void setName(String name){
			this.name=name;
		}
		
		public String getZone(){
			return zone;
		}

		public void setZone(String zone){
			this.zone=zone;
		}
		public String getType(){
			return type;
		}

		public void setType(String type){
			this.type=type;
		}
		public double getKm2(){
			return km2;
		}

		public void setKm2(double km2){
			this.km2=km2;
		}
			public String getUrl(){
			return url;
		}

		public void setUrl(String url){
			this.url=url;
		}
			public String getTypeOfArea(){
			return typeOfArea;
		}

		public void setTypeOfArea(String typeOfArea){
			this.typeOfArea=typeOfArea;
		}
		public String getVillage(){
			return village;
		}
		public void setVillage(String village){
			this.village=village;
		}
		public String getNeighborhood(){
			return neighborhood;

		}
		public void setNeighborhood(String neighborhood){
			this.neighborhood=neighborhood;
		}
		public Event[] getEventArray(){
			return eventArray;
		}
		public Specie[] getSpecieArray(){
			return specieArray;
		}
		public boolean addEvent(String event, int day, int month, int year, String who, double value, String description) {

		boolean stopFlag = false;

		Event myEvent = new Event(event, day, month, year, who, value, description);
		
		for (int i = 0; i < eventArray.length && !stopFlag; i++) {
			
			if (eventArray[i] == null) {

				eventArray[i] = myEvent;
				stopFlag = true;
			

			}

		}

		return stopFlag;
}
public boolean addSpecie(String type, String name, String scienceName, String migratory, String specieType) {

		boolean stopFlag = false;

		Specie mySpecie = new Specie(type, name, scienceName, migratory, specieType);
		
		for (int i = 0; i < specieArray.length && !stopFlag; i++) {
			
			if (specieArray[i] == null) {

				specieArray[i] = mySpecie;
				stopFlag = true;
			

			}

		}

		return stopFlag;
}
	}

/*@Override
	public String toString() {
		return "\n name" + name + "\n La zona en la que se encuentra ubicado es :" +zone+ "\nEl humedal es de tipo: " + type + "\nLa cantidad de km2 que tiene el humedal son: " + km2 + "\nEl url del humedal es: " + url + "\n El humedal fue declarado como area: " +typeOfArea;
		
	@Override
	public String toString() {

		String msg = "";

		msg += "\nEl nombre del humedal es:" +name "\nLa zona en la que se encuntra ubicado su humedal es: " + zone + "\nEl humedal es de tipo: " + type + "\nLa cantidad de km2 que contiene el humedal son:  " + km2 + "\nEl url de la foto del humedal es: " + url + "\nSu humedal fue dclarodo como area: " + typeOfArea;
	return msg;
	}
	}
*/

