package model;

public class Event {

private String event;
private Date date;
private String who;
private double value;
private String description;



	public Event(String event, int day, int month, int year, String who, double value, String description){

		this.event=event;
		this.date= new Date(day, month, year);
		this.who=who;
		this.value=value;
		this.description=description;

}
	public String getEvent(){
		return event;
	}

	public void setEvent(String event){
		this.event=event;
	}
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setDate(int day, int month, int year) {
		this.date = new Date(day, month, year);
	}
	public String getWho(){
		return who;
	}

	public void setWho(String who){
		this.who=who;
	}
	public double getValue(){
		return value;

	}
	public void setValue(double value){
	this.value=value;
	}
	public String getDescription(){
		return description;
	}	

	public void setDescription(String description){
		this.description=description;
	}

@Override
	public String toString() {
		return "type of event: " +event+ "date of the event: " +date+ "who performs the event: " +who+ "price of the event: " +value+ "description of the event: " +description;
	}
}


