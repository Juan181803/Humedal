package ui;

import java.util.Scanner;

import model.WetlandController;



public class Dagma {
	public static WetlandController controller;

	public static Scanner reader;

	public static void main(String[] args) {

			init();
		showMainMenu();

	}

	public static void init() {

		reader = new Scanner(System.in);
		controller = new WetlandController();

	}/**
	* Descripción: muestra el menu
	*/

	public static void showMainMenu() {

		System.out.println("Welcome to Wetland Software");

		boolean stopFlag = false;

		while (!stopFlag) {

			System.out.println("\nType an option");
			System.out.println("1. Create wetland");
			System.out.println("2. add a new specie to the wetland");
			System.out.println("3. Register an event fot a Wetland");
			System.out.println("4. años de manteinmiento");
			System.out.println("5. En construccion");
			System.out.println("6. En construccion");
			System.out.println("7. En construccion");
			System.out.println("8. En construccion");
			System.out.println("0. Exti");


			int mainOption = reader.nextInt();

			switch (mainOption) {

			case 1:
				createWetland();
				break;
			case 2:
				createSpecie();
				break;
			case 3: 
				createEvent();
				break;
			case 4:
				maintenance();
			case 0:
				stopFlag = true;
				System.out.println("Thanks for using our system");
				break;
			default:
				System.out.println("You must type a valid option");
				break;

			}

		}

	}
	/**
	* Descripción: Crea el humedal
	*/
	public static void createWetland(){
	 	String neighborhood = "";
	 	String village = "";
		String zone = "";
		String type = "";
		String area = "";
			System.out.println("Type the Wetlands's information: ");

			System.out.println("Name: ");
			String name = reader.next();
			System.out.println("Zone where the wetland is located: ");
			System.out.println("1. Urban ");
			System.out.println("2. Rural ");
			int zoneOption = reader.nextInt();
			switch (zoneOption){
			case 1:
				 zone  = "urban";
				break;
			case 2:
				zone = "rural";
				break;
			}
	//System.out.println(myWetland.getZone());
			if (zoneOption==1){
				System.out.println("type the name of the village where the wetland is located");
				 village = reader.nextLine();
						village = reader.nextLine();
			}else {
				System.out.println("type the name of the neighborhood where the wetland is located");
				 neighborhood = reader.nextLine();	
			}
			System.out.println("type of wetland");
			System.out.println("1. private");
			System.out.println("2. public");

			int typeOption = reader.nextInt();

			switch (typeOption){
			case 1:
				type = "private";
				break;
			case 2: 
				type = "public";
				break;
			}

			System.out.println("type the size of the werland in km2");

			double km2 = reader.nextDouble();

			System.out.println("put the url of the photo of the wetland");

			String url = reader.nextLine();

			System.out.println("Choose the type of area");
			System.out.println("1. Protected");
			System.out.println("2. Unprotected");
			int areaOption = reader.nextInt();
			switch (areaOption){
			case 1: 
				area = "Protected";
				break;
			case 2:

				area= "Unprotected";
				break;
			}
 			//Forma de mostrar los humedales registraods		
 					controller.saveWetland(name, zone, type, km2, url, area, village, neighborhood);
 					System.out.println("These are the Wetlands currently registered:" + controller.showWetlandsList());

	

			}
			/**
	* Descripción: Crea el evento
	*/

		public static void createEvent(){
			String wetlandID = "";
		
			String event = "";
 			System.out.println("These are the Wetlands currently registered:" + controller.showWetlandsList());
 			System.out.println("type the id of the wetland you want to register the event for");
 			 wetlandID = reader.nextLine();
 			 wetlandID = reader.nextLine();
			System.out.println("Choose the type of the event that you want to create");
			System.out.println("1. Maintenance");
			System.out.println("2. School Visits");
			System.out.println("3. Improvement activities");
			System.out.println("4. Celebrations");
			int caseEvent = reader.nextInt();
			switch (caseEvent){
			case 1: event = "Maintenance";
				break;
			case 2: event = "School visits";
				break;
			case 3: event = "Improvement activities";
				break;
			case 4: event = "Celebrations";
				break;
			}
			System.out.println("Type the date of the event(YYYY-MM-DD): ");
			String date = reader.next();

			int year = Integer.parseInt(date.split("-")[0]);
			int month = Integer.parseInt(date.split("-")[1]);
			int day = Integer.parseInt(date.split("-")[2]);
			System.out.println("Who performs the event:");
			String who = reader.nextLine();
			who = reader.nextLine();
			System.out.println("Type the price of the event: ");
			double value = reader.nextDouble();
			System.out.println("Type a description of the event: ");
			String description = reader.nextLine();
			description = reader.nextLine();
if (controller.saveEvent(wetlandID, event, day, month, year, who, value, description)) {
			System.out.println("The event: " + event + " was successfully registered");
		} else {
			System.out.println("The event: " + event + " couldn't be registered");
		}
			
		}
		/**
	* Descripción: Crea la especie
	* 
	* 
	*/
		public static void createSpecie(){
			String specieID = "";
			String type = "";
			String specieType = "";
 			System.out.println("These are the Wetlands currently registered:" + controller.showWetlandsList());
 			System.out.println("type the id of the wetland you want to register the specie for");
 			 specieID = reader.nextLine();
 			 specieID = reader.nextLine();
 			 System.out.println("Select the type of spece that you want to register");
 			 System.out.println("1. Flora");
 			 System.out.println("2. Fauna");
 			 int caseOption = reader.nextInt();
 			 switch(caseOption){
 			 case 1:
 			 	type = "Flora";
 			 	break;
 			 case 2:
 			 	type = "Fauna";
 			 	break;
 			 }
 			 	System.out.println("type the name of the specie");
 			 	String name = reader.nextLine();
 			 	 name = reader.nextLine();
 			 	System.out.println("type the scientific name");
 			 	String scienceName = reader.nextLine();
 			 	System.out.println("type if the specie is migratory ");
 			 	String migratory = reader.nextLine();
 			 	System.out.println("Select your type of specie");
 			 	 System.out.println("1. terrestial flora");
 			 	 System.out.println("2. aquatic flora");
 			 	 System.out.println("3. birds");
 			 	 System.out.println("4. mammals");
 			 	 System.out.println("5. aquatic");
 			 	 int caseOption2 = reader.nextInt();
 			 	 switch(caseOption2){
 			 	 case 1: specieType = "terrestial flora";
 			 	 	break;
 			 	 case 2: specieType = "aquatic flora";
 			 	 	break;
 			 	 case 3: specieType = "birds";
 			 	 	break;
 			 	 case 4: specieType = "mammals";
 			 	 	break;
 			 	 case 5: specieType = "aquatic";
 			 	 }
 			 	 if (controller.saveSpecie(specieID, type, name, scienceName, migratory, specieType)) {
			System.out.println("The specie: " + name + " was successfully registered");
		} else {
			System.out.println("The specie: " + name + " couldn't be registered");
		}
		//controller.saveSpecie(specieID, type, name, scienceName, migratory, specieType);

 			 
 			}
 		


/**
	* muestra la cantidad de manenimientos, conectando el metodo de el controlador
	* 
	* 
	*/
		public static void maintenance(){
			System.out.println("Ingrese el año que desa consiultar");
			int userYear = reader.nextInt();

			System.out.println(controller.maintenancePerYear(userYear));
		}













	}































	
